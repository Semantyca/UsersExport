<?php

namespace Semantyca\Component\Usersexport\Administrator\Helper;

class Constants
{
	public const JSON_CONTENT_TYPE = 'Content-Type: application/json; charset=UTF-8';

	const COMPONENT_NAME = "com_usersexport";

}
